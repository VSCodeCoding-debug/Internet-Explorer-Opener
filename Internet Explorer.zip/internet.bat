@echo off
powershell -ExecutionPolicy Bypass -Command "New-Object -COMObject InternetExplorer.Application -Property @{Navigate2='about:blank'; Visible=$true}"